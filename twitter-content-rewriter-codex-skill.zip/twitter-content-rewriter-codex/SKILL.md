---
name: twitter-content-rewriter
description: Transform a source social-media post URL into an original X/Twitter post in the user's voice, plus two original visual concepts or generated images. Use when the user provides a post link and wants a ready-to-review X content package.
---

# Twitter Content Rewriter

## Goal

Turn a source social-media post into a genuinely original X/Twitter content package.

Primary workflow:

`source URL -> inspect source -> extract idea/facts -> create original angle -> write from scratch -> create two original visuals -> return review-ready package`

This skill is for content transformation, not automatic publishing. Unless the user explicitly asks to connect a publishing API, stop at a review-ready package.

## Core principle: transform the idea, not the wording

Treat the source as research material.

Do NOT:
- paraphrase sentence-by-sentence;
- swap synonyms;
- preserve the source's sentence/order structure;
- copy the source's images, branding, artwork, or layout;
- imitate a living creator's distinctive writing voice;
- claim something is original when it remains substantially copied.

DO:
- identify the underlying idea;
- separate facts from opinions and wording;
- develop a fresh hook;
- choose a different structure;
- add an original interpretation, example, analogy, or takeaway when appropriate;
- write the final post from the idea brief rather than from the source text.

If the output still reads like a paraphrase, discard it and rewrite from the extracted idea.

## Inputs

The user may provide:
- a source post URL;
- pasted source text;
- screenshots of the source;
- language;
- tone;
- target length;
- audience;
- desired topic angle;
- visual style;
- number of images.

Default values:
- language: simple English;
- tone: human, conversational, thoughtful;
- length: 80–180 words;
- images: 2;
- publishing: manual review by user.

## Source inspection

When a URL is supplied:
1. Use available web/browser capabilities to inspect it.
2. Extract the visible post text and relevant context.
3. Identify the author's main claim or insight.
4. Extract important factual claims separately.
5. Note what makes the source interesting.
6. If the source cannot be accessed, do not guess. Ask for pasted text or screenshots.

If current/factual claims matter, verify them using reliable sources when appropriate.

Do not reproduce long source passages. Use only the amount of source text necessary for analysis.

## Internal transformation stages

### Stage 1 — Source brief

Create an internal brief containing:
- Core idea
- Main claim
- Key facts
- Supporting evidence/examples
- Emotional or narrative angle
- Why the idea is interesting

### Stage 2 — Original angle

Select the strongest suitable angle:
- contrarian observation
- practical lesson
- simplified explanation
- "what this actually means"
- prediction
- product/design/business implication
- India-specific interpretation when genuinely relevant
- reflective observation without inventing personal experience

### Stage 3 — Original X post

Write from scratch.

Rules:
- strong first line;
- short paragraphs;
- clear progression;
- natural punctuation;
- no unnecessary hashtags;
- no forced emojis;
- avoid corporate filler;
- do not make claims stronger than the evidence;
- never invent personal experiences.

Avoid generic AI phrases such as:
- "game changer"
- "revolutionary"
- "in today's fast-paced world"
- "unlock the power of"
- "the future is here"

### Stage 4 — Self-check

Before returning the post, check:
- Is it independently understandable?
- Is the wording substantially different?
- Is the structure different?
- Does it contain an original angle?
- Did I accidentally retain distinctive source phrasing?
- Are factual claims accurate?
- Did I invent anything?
- Does it sound human?
- Is it appropriate for X?

If any answer is poor, rewrite.

## User voice

Read `references/voice-profile.md`.

If the project contains user-provided examples of the user's own writing, use those examples as the strongest style signal.

Never copy phrases from examples mechanically. Infer patterns such as:
- sentence length;
- hook style;
- paragraph rhythm;
- humor level;
- Hinglish usage;
- punctuation;
- emoji frequency;
- preferred level of opinion.

If the user says "make it sound like me" and there are no useful examples, ask for 3–5 examples of their own posts.

Never fabricate a first-person story or experience.

## Language

Support:
- English
- Hinglish
- Hindi
- any language explicitly requested

Do not perform literal translation when rewriting. Reconstruct the idea naturally in the requested language.

## Visuals

Create TWO genuinely different visual directions based on the underlying idea.

### Visual 1 — Conceptual/editorial
Use a clean conceptual metaphor or editorial illustration.

### Visual 2 — Alternative interpretation
Use a clearly different scene, metaphor, composition, or infographic/editorial treatment.

Never recreate:
- the source image composition;
- source branding;
- source logo;
- source artwork;
- exact visual layout.

For each visual, define:
- purpose;
- composition;
- subject;
- mood;
- aspect ratio;
- image-generation prompt;
- optional minimal on-image text.

Prefer little or no text inside generated images. Never place fake statistics, fake logos, or unverifiable claims into visuals.

If image-generation tooling is available in the current Codex environment and the user asks for actual images, generate both. Otherwise provide production-ready prompts and clearly label them as prompts.

## Output contract

Return exactly this structure unless the user asks for another format:

# Ready-to-post X package

## Post
A clean, copyable final X post.

## Image 1
The generated image if available, otherwise the production-ready prompt.

One-line explanation of the visual.

## Image 2
The generated image if available, otherwise the production-ready prompt.

One-line explanation of the visual.

## Source insight
1–3 bullets describing the underlying idea used.

## Originality check
Briefly confirm:
- rebuilt from the underlying idea;
- not copied sentence-by-sentence;
- visuals are newly conceived.

Do not provide a long process explanation unless asked.

## Optional controls

Respect these user-provided fields:
- `Language:`
- `Tone:`
- `Length:`
- `Audience:`
- `Topic angle:`
- `Image style:`
- `Number of images:`
- `Include hashtags: yes/no`

If the user says "just do it", make reasonable defaults and do not ask unnecessary questions.

## Publishing boundary

The default behavior is:

`source -> AI transformation -> user review -> user publishes`

Do not automatically post to X.

If the user explicitly requests X API publishing, treat publishing as a separate side-effecting integration. Require the appropriate API credentials/connection and preserve a user approval step unless the user explicitly asks for unattended publishing.

Never expose secrets.

## Codex implementation guidance

If this skill is used while building an automation/app:
- keep source fetching, content generation, image generation, and publishing as separate steps;
- keep publishing disabled by default;
- make the transformation output inspectable before any side effect;
- store user voice examples separately from runtime prompts when practical;
- use environment variables for API credentials;
- never print API keys;
- provide a local smoke test with a sample source input when building a runnable implementation.

If using the OpenAI API in a Codex build, follow the installed OpenAI API-key credential gate before building, running, or testing API-backed code.

## Failure handling

If the source URL is inaccessible:
- say that the source could not be read;
- ask for the post text or screenshots;
- do not invent the source.

If image generation fails:
- still return two detailed visual prompts.

If the source contains unsupported/unsafe material:
- follow applicable safety policies;
- do not blindly transform prohibited content.
