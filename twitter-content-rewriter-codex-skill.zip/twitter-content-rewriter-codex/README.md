# Twitter Content Rewriter — Codex Skill

This Codex skill turns a source social-media post into an original X/Twitter post and two original visual directions.

## Install

Place the folder at:

`~/.codex/skills/twitter-content-rewriter/`

The folder must contain:

```text
twitter-content-rewriter/
├── SKILL.md
└── references/
    └── voice-profile.md
```

You can also keep a project-local copy if your Codex setup supports project skills.

## Use

Give Codex a source URL and a request such as:

`Use the Twitter Content Rewriter skill on this post: <URL>. Make it Hinglish, conversational, and create two images.`

Or:

`Rewrite this for my X in my style. 120 words max. Two conceptual images: <URL>`

## Personalize

Add 10–20 examples of the user's own posts to:

`references/voice-profile.md`

The skill will use them to infer the user's writing patterns.

## Important

The skill is designed to create genuinely original expression of an idea. It is not designed to disguise copied text or reproduce another creator's distinctive wording or artwork.

By default it stops before publishing. Publishing can be added later as a separately approved API integration.
