# Voice Profile

Use this as the default writing profile until the user provides stronger examples.

## Default style

- Human
- Conversational
- Simple English
- Clear and direct
- Curious
- Slightly opinionated when appropriate
- Non-corporate
- Avoids sounding AI-generated

## Typical rhythm

1. Strong hook
2. One clear observation
3. Explanation/example
4. Memorable takeaway

## Language preferences

Prefer:
- short sentences;
- everyday vocabulary;
- natural paragraph breaks;
- occasional Hinglish when requested.

Avoid:
- heavy vocabulary for the sake of sounding smart;
- corporate jargon;
- excessive hashtags;
- unnecessary emojis;
- generic motivational filler.

## Add the user's examples here

When the user gives examples of their own X posts, add them below this section. Use enough examples to learn recurring patterns without copying their exact wording.

The model should infer:
- hook patterns;
- sentence length;
- paragraph size;
- humor;
- Hinglish/Hindi usage;
- punctuation;
- emoji habits;
- degree of opinion;
- preferred subject matter.

Never mechanically reuse distinctive sentences from the examples.
